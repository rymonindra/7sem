<?php
session_start();
include 'db.php';

$error = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // VULNERABILITY (SQL Injection - Lab Purpose)
    $sql = "SELECT * FROM teachers WHERE username = '$username' AND password = '$password'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $teacher = $result->fetch_assoc();
        $_SESSION['teacher_id'] = $teacher['id'];
        $_SESSION['teacher_name'] = $teacher['name'];
        setcookie("PHPSESSID_LAB", "session_token_xyz_authenticated_user_secret", time() + 3600, "/");
        header("Location: dashboard.php");
        exit();
    } else {
        $error = "Invalid Security Credentials!";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>BUBT - Attendance Management System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="login-container">
        <!-- BUBT Varsity Banner Box -->
        <div class="varsity-banner">
            <h2>BUBT</h2>
            <p>Attendance Management System</p>
        </div>
        
        <div class="login-form-body">
            <h3>Faculty Portal Login</h3>
            
            <?php if(!empty($error)) echo "<div class='error-msg'>$error</div>"; ?>
            
            <form method="POST" action="login.php">
                <label style="font-size: 13px; font-weight: 600; color: #475569;">Faculty Username</label>
                <input type="text" name="username" placeholder="e.g. ripon" required>
                
                <label style="font-size: 13px; font-weight: 600; color: #475569;">Account Password</label>
                <input type="password" name="password" placeholder="••••••••" required>
                
                <input type="submit" value="Secure Login">
            </form>
        </div>
    </div>
</body>
</html>
