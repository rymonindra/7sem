<?php
session_start();
if (!isset($_SESSION['teacher_id'])) {
    header("Location: login.php");
    exit();
}
include 'db.php';
$subject_id = isset($_GET['subject_id']) ? $_GET['subject_id'] : 1; 
$subject = $conn->query("SELECT * FROM subjects WHERE id = $subject_id")->fetch_assoc();
$dept_id = $subject['dept_id'];
?>
<!DOCTYPE html>
<html>
<head>
    <title>BUBT - Take Attendance</title>
    <link rel="stylesheet" href="style.css">
    <script>
        function applyTag(studentId, text) {
            var field = document.getElementById('comment_' + studentId);
            field.value = field.value === '' ? text : field.value + ', ' + text;
        }
    </script>
</head>
<body>
    <div class="navbar">
        <div class="navbar-brand">
            <h1>Course Roster: <?php echo $subject['subject_name']; ?></h1>
            <p>Verification Sheet | Current Server Date: <?php echo date('Y-m-d'); ?></p>
        </div>
        <div>
            <a href="dashboard.php" class="btn-danger" style="background:#6b7280;">⬅ Back</a>
        </div>
    </div>

    <div class="container" style="max-width:950px;">
        <div class="card">
            <form method="POST" action="submit_attendance.php">
                <input type="hidden" name="subject_id" value="<?php echo $subject_id; ?>">
                <table>
                    <tr><th style="width:80px;">UID</th><th>Full Name</th><th style="width:200px;">Status Matrix</th><th>Evaluation Note</th></tr>
                    <?php 
                    $students = $conn->query("SELECT * FROM students WHERE dept_id = $dept_id");
                    while($student = $students->fetch_assoc()) { 
                        $sid = $student['id'];
                    ?>
                        <tr>
                            <td><code>#00<?php echo $sid; ?></code></td>
                            <td><strong><?php echo $student['student_name']; ?></strong></td>
                            <td>
                                <div class="status-pill-group">
                                    <label><input type="radio" name="status[<?php echo $sid; ?>]" value="Present" checked> Present</label>
                                    <label><input type="radio" name="status[<?php echo $sid; ?>]" value="Absent"> Absent</label>
                                </div>
                            </td>
                            <td>
                                <div class="comment-box-wrapper">
                                    <div class="tag-cloud">
                                        <span class="tag-node" onclick="applyTag(<?php echo $sid; ?>, 'Late 10m')">+ Late 10m</span>
                                        <span class="tag-node" onclick="applyTag(<?php echo $sid; ?>, 'Sick Leave')">+ Medical</span>
                                    </div>
                                    <input type="text" id="comment_<?php echo $sid; ?>" name="comment[<?php echo $sid; ?>]" class="input-field" placeholder="Write logs..." style="padding:6px 10px; font-size:12px; margin:0;">
                                </div>
                            </td>
                        </tr>
                    <?php } ?>
                </table>
                <div style="margin-top:20px; text-align:right;">
                    <input type="submit" value="Save & Publish Attendance" class="btn-primary" style="width:auto; padding:12px 35px;">
                </div>
            </form>
        </div>
    </div>
</body>
</html>
